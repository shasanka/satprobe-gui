import React, { Component } from "react";
import AppBarDrawerComponent from "./components/AppBarDrawerComponent";

export class App extends Component {
  render() {
    return (
      <div>
        <AppBarDrawerComponent/>
      </div>
    )
  }
}

export default App

