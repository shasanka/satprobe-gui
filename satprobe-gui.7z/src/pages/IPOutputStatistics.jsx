import React, { Component } from "react";
import { Typography } from "@material-ui/core";

export class IPOutputStatistics extends Component {
  render() {
    return (
      <div>
        <Typography paragraph>Ip Output Statistics </Typography>
      </div>
    );
  }
}

export default IPOutputStatistics;
