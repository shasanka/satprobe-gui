import React, { Component } from "react";
import { Typography } from "@material-ui/core";

export class TerminalStatistics extends Component {
  render() {
    return (
      <div>
        <Typography paragraph>Terminal Statistics</Typography>
      </div>
    );
  }
}

export default TerminalStatistics;
