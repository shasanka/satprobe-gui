import React, { Component } from "react";
import { Typography } from "@material-ui/core";

export class CarrierStatistics extends Component {
  render() {
    return (
      <div>
        <Typography paragraph>Carrier Statistics </Typography>
      </div>
    );
  }
}

export default CarrierStatistics;
