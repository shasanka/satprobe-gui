import React, { Component } from "react";
import { Typography } from "@material-ui/core";

export class DecoderStatistics extends Component {
  render() {
    console.log("decoder");
    return (
      <div>
        <Typography>Decoder Statistics</Typography>
      </div>
    );
  }
}

export default DecoderStatistics;
